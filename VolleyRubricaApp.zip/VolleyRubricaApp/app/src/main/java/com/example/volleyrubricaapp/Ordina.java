package com.example.volleyrubricaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Ordina extends AppCompatActivity {

    private TextView desc;
    private TextView listaord;
    private RequestQueue miaCoda4=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordina);
        miaCoda4= Volley.newRequestQueue(this);
        desc=findViewById(R.id.txtdescrizione);
        listaord=findViewById(R.id.txtlistaord);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Response.Listener risposta= new Response.Listener() {
            @Override
            public void onResponse(Object response) {
                listaord.setText(response.toString());
            }
        };
        String url="http://192.168.76.83:1393/ordina";
        StringRequest richiesta=new StringRequest(Request.Method.POST, url, risposta, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        miaCoda4.add(richiesta);
    }
}

package com.example.volleyrubricaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private RequestQueue miaCoda=null;
    private Button btnCarica=null;
    private Button btnvisualizza=null;
    private Button btnElimina=null;
    private Button btnordina=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        miaCoda= Volley.newRequestQueue(this);
        btnCarica=findViewById(R.id.btncarica);
        btnvisualizza=findViewById(R.id.btnvisualizza);
        btnElimina=findViewById(R.id.btnelimina);
        btnordina=findViewById(R.id.btnordina);

    }

    @Override
    protected void onResume() {
        super.onResume();

        btnCarica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent miacarica= new Intent(getApplicationContext(),Carica.class);
                startActivity(miacarica);

            }
        });


        btnElimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent miaelimina= new Intent(getApplicationContext(),Elimina.class);
                startActivity(miaelimina);

            }
        });

        btnvisualizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent miavisualizza= new Intent(getApplicationContext(),Visualizza.class);
                startActivity(miavisualizza);

            }
        });

        btnordina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent miaordina= new Intent(getApplicationContext(),Ordina.class);
                startActivity(miaordina);

            }
        });
    }
}

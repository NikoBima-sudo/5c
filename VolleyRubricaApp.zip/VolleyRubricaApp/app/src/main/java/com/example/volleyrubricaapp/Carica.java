package com.example.volleyrubricaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Carica extends AppCompatActivity {

    private TextView txtnome;
    private TextView txtcognome;
    private TextView txttelefono;
    private EditText nome;
    private EditText cognome;
    private EditText telefono;
    private Button carica;

    private RequestQueue miaCoda=null;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carica);
        miaCoda= Volley.newRequestQueue(this);
        txtnome=findViewById(R.id.txtnome);
        txtcognome=findViewById(R.id.txtcognome);
        txttelefono=findViewById(R.id.txttelefono);
        nome=findViewById(R.id.edxnome);
        cognome=findViewById(R.id.edxcognome);
        telefono=findViewById(R.id.edxtelefono);
        carica=findViewById(R.id.bottonecarica);


    }

    @Override
    protected void onResume() {
        super.onResume();
        carica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://192.168.76.83:1393/carica";
                final StringRequest request=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map var=new HashMap();
                        var.put("nome",nome.getText().toString());
                        var.put("cognome",cognome.getText().toString());
                        var.put("telefono",telefono.getText().toString());
                        return var;
                    }
                };
                miaCoda.add(request);
            }
        });
    }

}
